#!/usr/bin/env python3
"""
ROS2 YOLO Detection Node using OpenVINO
订阅配置的深度相机 RGB 图像，使用 YOLO11n + OpenVINO 进行目标检测
"""

import os
import sys
from pathlib import Path


def _maybe_reexec_with_target_python() -> None:
    """Re-exec with conda Python when launched by system Python."""
    target_python = os.environ.get(
        'YOLO_NODE_PYTHON',
        sys.executable,
    )
    try:
        target = Path(target_python)
        if not target.exists():
            return
        if os.path.realpath(sys.executable) == os.path.realpath(str(target)):
            return
        os.execv(
            str(target),
            [
                str(target),
                '-m',
                'yolo_node.yolo_detector',
                *sys.argv[1:],
            ],
        )
    except Exception:
        return


_maybe_reexec_with_target_python()


def _ensure_ultralytics_path() -> None:
    candidates = []
    env_root = os.environ.get('ULTRALYTICS_ROOT')
    if env_root:
        candidates.append(Path(env_root))
    for p in candidates:
        try:
            if not p.exists():
                continue
            # repo root containing an ``ultralytics`` package
            if (p / 'ultralytics').exists() and str(p) not in sys.path:
                sys.path.insert(0, str(p))
                return
            # direct package dir fallback
            if p.name == 'ultralytics' and (p / '__init__.py').exists():
                parent = p.parent
                if str(parent) not in sys.path:
                    sys.path.insert(0, str(parent))
                return
        except Exception:
            continue


_ensure_ultralytics_path()

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import cv2
import numpy as np
import yaml
import tempfile
import shutil
import traceback
import threading
import time
import json
from collections import defaultdict, deque
from std_msgs.msg import String

try:
    import yolo_logic as _logic           # installed next to this script (lib/yolo_node/)
except ImportError:                        # pragma: no cover - source-tree / package layout
    from yolo_node import yolo_logic as _logic


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value).strip().lower() in ("1", "true", "yes", "on")


_TELEMETRY_PATCH = (False, 'not attempted')   # (applied, detail); reported in /yolo/status and logged once


def _disable_openvino_telemetry() -> None:
    """Process-local opt-out of OpenVINO's GA4 telemetry (no global consent file is written).

    GA4Backend.send() forks a multiprocessing.Process that does a blocking HTTPS urlopen.  The fork inherits
    rclpy's SIGTERM handler (flag only), so the library's own terminate() after 3 s is ignored and the child
    stays stuck in connect() on a robot without internet; at interpreter exit multiprocessing then join()s it
    forever -> the node ignores SIGINT until launch SIGKILLs it (see issue1 RESULTS.md).
    """
    global _TELEMETRY_PATCH
    _TELEMETRY_PATCH = _logic.disable_openvino_telemetry()


def _reap_helper_processes() -> None:
    """Kill leftover multiprocessing children so interpreter exit can never block on them."""
    try:
        import multiprocessing
        kids = multiprocessing.active_children()
        for c in kids:
            try:
                c.kill()        # SIGKILL: forked children inherit rclpy's SIGTERM handler and ignore SIGTERM
            except Exception:
                pass
        for c in kids:
            c.join(timeout=1.0)
    except Exception:
        pass


_disable_openvino_telemetry()

# Ultralytics for YOLO model
from ultralytics import YOLO


def _reshape_image(data: np.ndarray, msg: Image, channels: int) -> np.ndarray:
    h, w = int(msg.height), int(msg.width)
    if h <= 0 or w <= 0:
        raise ValueError("Invalid image shape")

    elem = data.dtype.itemsize
    step = int(msg.step) if msg.step else w * channels * elem
    row_elems = step // elem

    if channels == 1:
        if row_elems == w:
            return data.reshape(h, w)
        return data.reshape(h, row_elems)[:, :w]

    if row_elems == w * channels:
        return data.reshape(h, w, channels)
    return data.reshape(h, row_elems)[:, : w * channels].reshape(h, w, channels)


def _image_msg_to_bgr(msg: Image) -> np.ndarray:
    enc = (msg.encoding or "").lower()
    if enc not in ("bgr8", "rgb8", "mono8"):
        raise ValueError(f"Unsupported image encoding: {msg.encoding}")

    dtype = np.dtype(np.uint8)
    if msg.is_bigendian:
        dtype = dtype.newbyteorder(">")

    data = np.frombuffer(msg.data, dtype=dtype)
    if enc in ("bgr8", "rgb8"):
        img = _reshape_image(data, msg, 3)
        if enc == "rgb8":
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        return img

    gray = _reshape_image(data, msg, 1)
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)


def _bgr_to_image_msg(img: np.ndarray, header) -> Image:
    if img.dtype != np.uint8:
        raise ValueError("Expected uint8 image for bgr8 encoding")
    if img.ndim != 3 or img.shape[2] != 3:
        raise ValueError("Expected HxWx3 image for bgr8 encoding")

    out = Image()
    out.header = header
    out.height = int(img.shape[0])
    out.width = int(img.shape[1])
    out.encoding = "bgr8"
    out.is_bigendian = False
    out.step = int(img.shape[1] * 3)
    out.data = np.ascontiguousarray(img).tobytes()
    return out


class YoloDetectorNode(Node):
    def __init__(self):
        super().__init__('yolo_node')
        
        # 声明参数
        self.declare_parameter(
            'model_path',
            # 与 launch 文件一致；也可用 TZB_OPENVINO_MODEL 或 model_path 覆盖。
            os.environ.get(
                'TZB_OPENVINO_MODEL',
                '/home/tzb/tzb_ws/src/best_openvino_model/blue_block_v1_640_openvino_model'))
        self.declare_parameter('conf_threshold', 0.6)
        self.declare_parameter('iou_threshold', 0.45)
        self.declare_parameter('publish_conf_threshold', 0.6)
        self.declare_parameter('publish_hold_seconds', 0.0)
        self.declare_parameter('device', 'cpu')  # 'cpu' or 'gpu' for OpenVINO
        # self.declare_parameter('image_topic', 'camera/camera/color/image_raw')
        self.declare_parameter('image_topic', '/camera/color/image_raw')

        self.declare_parameter('detection_topic', 'yolo/detections')
        self.declare_parameter('annotated_image_topic', 'yolo/annotated_image')
        self.declare_parameter('left_or_right', 1)
        self.declare_parameter('multi_target_selection', 'confidence')  # or legacy 'area_left_right'
        # Must match the default model's metadata names ({0: 'blue block'}); matching is normalised
        # (case, '_' / '-' / whitespace) so 'blue_block' and 'blue block' are equivalent.
        self.declare_parameter('target_class', 'blue block')
        self.declare_parameter('status_topic', 'yolo/status')
        self.declare_parameter('status_period_sec', 1.0)
        self.declare_parameter('timing_log_enable', True)
        self.declare_parameter('timing_log_throttle_sec', 0.5)
        self.declare_parameter('image_queue_depth', 2)
        self.declare_parameter('NUC', False)
        self.declare_parameter('yolo_threads_default', 4)
        self.declare_parameter('yolo_threads_nuc', 6)
        self.declare_parameter('bbox_area_smoothing_enable', True)
        self.declare_parameter('bbox_area_history_len', 10)
        self.declare_parameter('bbox_area_min_history', 3)
        self.declare_parameter('bbox_area_jump_ratio', 0.55)
        
        # 获取参数
        model_path = self.get_parameter('model_path').value
        self.conf_threshold = self.get_parameter('conf_threshold').value
        self.iou_threshold = self.get_parameter('iou_threshold').value
        self.publish_conf_threshold = self.get_parameter('publish_conf_threshold').value
        self.publish_hold_seconds = self.get_parameter('publish_hold_seconds').value
        device = self.get_parameter('device').value
        self.device = device
        image_topic = self.get_parameter('image_topic').value
        detection_topic = self.get_parameter('detection_topic').value
        annotated_image_topic = self.get_parameter('annotated_image_topic').value
        self.left_or_right = int(self.get_parameter('left_or_right').value)
        self.multi_target_selection = str(self.get_parameter('multi_target_selection').value)
        self.target_class = str(self.get_parameter('target_class').value)
        status_topic = str(self.get_parameter('status_topic').value)
        self.status_period_sec = max(0.1, float(self.get_parameter('status_period_sec').value))
        self._target_norm = _logic.normalize_class_name(self.target_class)
        self._target_class_valid = False      # decided after the model (and its names) is loaded
        self.timing_log_enable = bool(self.get_parameter('timing_log_enable').value)
        self.timing_log_throttle_sec = float(self.get_parameter('timing_log_throttle_sec').value)
        self.image_queue_depth = max(1, int(self.get_parameter('image_queue_depth').value))
        self.NUC = _as_bool(self.get_parameter('NUC').value)
        self.yolo_threads_default = max(1, int(self.get_parameter('yolo_threads_default').value))
        self.yolo_threads_nuc = max(1, int(self.get_parameter('yolo_threads_nuc').value))
        self.bbox_area_smoothing_enable = _as_bool(self.get_parameter('bbox_area_smoothing_enable').value)
        self.bbox_area_history_len = max(1, int(self.get_parameter('bbox_area_history_len').value))
        self.bbox_area_min_history = max(1, int(self.get_parameter('bbox_area_min_history').value))
        self.bbox_area_jump_ratio = max(0.05, float(self.get_parameter('bbox_area_jump_ratio').value))
        self._last_timing_log_mono = 0.0
        self._haomu_area_histories = defaultdict(lambda: deque(maxlen=self.bbox_area_history_len))
        self._last_area_jump_log_mono = 0.0
        self._apply_compute_profile()
        
        # CV Bridge 用于图像转换
        self.bridge = CvBridge()
        self._cv_bridge_ok = True

        # 发布门控状态：仅当高置信度持续满足一段时间后才发布
        self.high_conf_start_time_sec: float | None = None
        self.publish_gate_open = False
        
        # ---- status topic: created BEFORE the model is loaded so a stuck / failed load is observable ----
        self._init_status_state(model_path)
        self.status_publisher = self.create_publisher(
            String, status_topic,
            QoSProfile(reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST, depth=10))
        self._publish_status(force=True)                      # LOADING_MODEL
        self._status_stop = threading.Event()
        self._status_thread = threading.Thread(
            target=self._status_loop, name='yolo_status_publisher', daemon=True)
        self._status_thread.start()

        # 仅加载 OpenVINO 模型
        self.get_logger().info(f'Loading YOLO model from: {model_path}')
        try:
            import importlib
            ultralytics = importlib.import_module('ultralytics')
            self.get_logger().info(f"Ultralytics version: {ultralytics.__version__}")
        except Exception:
            pass
        try:
            self.model = self._load_model(model_path, device)
        except BaseException as exc:
            # publish MODEL_FAILED, then re-raise so the process still fails loudly.
            with self._stat_lock:
                self._model_failed = True
                self._last_error = f'model load failed: {type(exc).__name__}: {exc}'[:400]
            for _ in range(2):
                try:
                    self._publish_status(force=True)
                except Exception:
                    pass
                time.sleep(0.3)
            self._status_stop.set()
            raise
        self.get_logger().info('YOLO model loaded successfully!')
        with self._stat_lock:
            self._model_names = _logic.names_as_dict(getattr(self.model, 'names', None))
        valid, ids, matched = _logic.resolve_target_class(self.target_class, self._model_names)
        self._target_class_valid = valid
        if valid:
            self.get_logger().info(
                f"target_class '{self.target_class}' matches model class ids {ids} {matched}")
        else:
            msg = (f"target_class '{self.target_class}' (normalised '{self._target_norm}') matches NO model class; "
                   f"model names={self._model_names}. Nothing will be published on the detection topic.")
            with self._stat_lock:
                self._last_error = msg[:400]
            self.get_logger().error(msg)
        
        # 延迟导入自定义消息 (编译后才能导入)
        from yolo_node.msg import Detection, DetectionArray
        self.Detection = Detection
        self.DetectionArray = DetectionArray
        
        # 创建订阅者 - 订阅配置的相机 RGB 话题
        # KEEP_LAST=2 + 后台线程覆盖 latest，可避免推理慢于相机帧率时旧图像堆积，同时保留极小缓冲。
        image_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=self.image_queue_depth,
            durability=DurabilityPolicy.VOLATILE,
        )
        self.image_subscription = self.create_subscription(
            Image,
            image_topic,
            self.image_callback,
            image_qos
        )
        self.get_logger().info(f'Subscribed to: {image_topic} (KEEP_LAST={self.image_queue_depth}, latest-frame only)')
        
        # 创建发布者 - 发布检测结果
        self.detection_publisher = self.create_publisher(
            DetectionArray,
            detection_topic,
            3
        )
        self.get_logger().info(f'Publishing detections to: {detection_topic}')
        
        # 创建发布者 - 发布带标注的图像 (可选)
        self.annotated_image_publisher = self.create_publisher(
            Image,
            annotated_image_topic,
            3
        )
        self.get_logger().info(f'Publishing annotated images to: {annotated_image_topic}')

        self.get_logger().info(
            f'Publish gating enabled: conf>{self.publish_conf_threshold} '
            f'for {self.publish_hold_seconds:.2f}s before publishing'
        )
        self.get_logger().info(
            f'target selection mode: target_class={self.target_class} '
            f'left_or_right={self.left_or_right} (0=left, 1=right) multi_target_selection={self.multi_target_selection}'
        )
        
        self.get_logger().info('YOLO Detector Node initialized successfully!')

        # 异步推理：仅保留最新帧，避免旧帧排队导致输出滞后
        self._image_lock = threading.Lock()
        self._image_cv = threading.Condition(self._image_lock)
        self._latest_image_item: tuple[Image, float] | None = None
        self._worker_running = True
        self._worker_thread = threading.Thread(
            target=self._inference_worker,
            name='yolo_inference_worker',
            daemon=True,
        )
        with self._stat_lock:
            self._model_ready = True
        self._worker_thread.start()
        self._publish_status(force=True)     # WAITING_IMAGE

    # ------------------------------------------------------------------ status topic
    def _init_status_state(self, model_path):
        self._stat_lock = threading.Lock()
        self._status_pub_lock = threading.Lock()
        self._status_model_path = str(model_path)
        self._model_failed = False
        self._model_ready = False
        self._model_names = {}
        self._images_received = 0
        self._first_image_mono = None
        self._last_image_mono = None
        self._last_inference_done_mono = None
        self._wait_since_mono = None       # recv time of the frame sitting in the slot (None = slot empty)
        self._busy_since_mono = None       # when the worker picked up the frame it is processing now
        self._inferences = 0
        self._inference_errors = 0
        self._convert_errors = 0
        self._worker_loop_errors = 0
        self._last_error = ''
        self._last_outcome = 'none'
        self._raw_last = 0
        self._target_last = 0
        self._max_target_conf_last = 0.0
        self._published_last = False
        self._published = 0
        self._last_state = None
        self._worker_thread = None
        self._telemetry_patch_applied, self._telemetry_patch_detail = _TELEMETRY_PATCH
        if not self._telemetry_patch_applied:
            # once per process (node is created once): the shutdown hang protection is degraded
            self.get_logger().warn(
                'OpenVINO telemetry opt-out patch NOT applied (' + self._telemetry_patch_detail +
                '); exit relies on child reaping only. Supported opt-out: opt_in_out --opt_out')

    def _compute_status(self) -> dict:
        now = time.monotonic()
        with self._stat_lock:
            last_img = self._last_image_mono
            done = self._last_inference_done_mono
            # stall = the oldest unfinished work (frame waiting in the slot, or frame being processed) is old
            unfinished = [t for t in (self._wait_since_mono, self._busy_since_mono) if t is not None]
            lag = (now - min(unfinished)) if unfinished else 0.0
            img_age = (now - last_img) if last_img is not None else None
            state = _logic.classify_state(
                model_failed=self._model_failed, model_ready=self._model_ready,
                images_received=self._images_received, last_image_age_s=img_age,
                inference_lag_s=lag, last_outcome=self._last_outcome,
                raw_detections_last=self._raw_last, target_detections_last=self._target_last,
                published_last=self._published_last)
            return {
                'state': state,
                'stamp': round(self.get_clock().now().nanoseconds / 1e9, 3),
                'model_path': self._status_model_path,
                'model_names': {str(k): v for k, v in self._model_names.items()},
                'target_class': self.target_class,
                'target_class_valid': bool(self._target_class_valid),
                'images_received': self._images_received,
                'last_image_age_s': None if img_age is None else round(img_age, 2),
                'inferences': self._inferences,
                'last_inference_age_s': None if done is None else round(now - done, 2),
                'inference_errors': self._inference_errors,
                'convert_errors': self._convert_errors,
                'worker_loop_errors': self._worker_loop_errors,
                'telemetry_patch_applied': bool(self._telemetry_patch_applied),
                'telemetry_patch_detail': self._telemetry_patch_detail,
                'worker_alive': bool(self._worker_thread is not None and self._worker_thread.is_alive()),
                'last_error': self._last_error,
                'raw_detections_last': self._raw_last,
                'target_detections_last': self._target_last,
                'max_target_conf_last': round(self._max_target_conf_last, 4),
                'publish_conf_threshold': self.publish_conf_threshold,
                'gate_open': bool(self.publish_gate_open),
                'published': self._published,
            }

    def _publish_status(self, force: bool = False):
        """Publish on state transition (always) and when force=True (1 Hz thread / explicit)."""
        d = self._compute_status()
        with self._status_pub_lock:
            changed = d['state'] != self._last_state
            if not (force or changed):
                return
            if changed:
                old, self._last_state = self._last_state, d['state']
                self.get_logger().info(f'[GRASP][detection][STATE] {old} -> {d["state"]}')
            self.status_publisher.publish(String(data=json.dumps(d, ensure_ascii=False)))

    def _status_loop(self):
        while not self._status_stop.wait(self.status_period_sec):
            try:
                self._publish_status(force=True)
            except Exception:
                pass        # context may be shutting down

    def _record_failure(self, kind: str, exc: BaseException):
        with self._stat_lock:
            if kind == 'convert':
                self._convert_errors += 1
                self._last_outcome = 'convert_error'
            else:
                self._inference_errors += 1
                self._last_outcome = 'inference_error'
            self._last_error = f'{kind}: {type(exc).__name__}: {exc}'[:400]

    def _record_success(self, raw_n, target_n, max_target_conf, published):
        with self._stat_lock:
            self._inferences += 1
            self._last_inference_done_mono = time.monotonic()
            self._last_outcome = 'ok'
            self._raw_last = raw_n
            self._target_last = target_n
            self._max_target_conf_last = max_target_conf
            self._published_last = bool(published)
            if published:
                self._published += 1
    

    def _apply_compute_profile(self):
        """Limit YOLO/OpenVINO CPU usage according to platform profile."""
        threads = self.yolo_threads_nuc if self.NUC else self.yolo_threads_default
        threads = max(1, int(threads))
        os.environ['NUC'] = 'true' if self.NUC else 'false'
        os.environ['YOLO_COMPUTE_PROFILE'] = 'nuc' if self.NUC else 'jiaolong16q'
        os.environ['OV_CPU_THREADS_NUM'] = str(threads)
        os.environ['OPENVINO_CPU_THREADS_NUM'] = str(threads)
        os.environ.setdefault('OMP_NUM_THREADS', str(threads))
        os.environ.setdefault('OPENBLAS_NUM_THREADS', str(threads))
        os.environ.setdefault('MKL_NUM_THREADS', str(threads))
        os.environ.setdefault('NUMEXPR_NUM_THREADS', str(threads))
        profile = 'NUC12 i7 12C/20T' if self.NUC else '机械革命蛟龙16Q 8C/16T'
        self.get_logger().info(f'YOLO compute profile: {profile}, OpenVINO/OMP threads≈{threads}')

    def _stable_haomu_area(self, det, slot: int) -> float:
        """Return history-averaged area for ranking to suppress one-frame box size spikes."""
        area = max(1.0, float(det.width) * float(det.height))
        hist = self._haomu_area_histories[int(slot)]
        if not self.bbox_area_smoothing_enable:
            hist.append(area)
            return area

        if len(hist) >= self.bbox_area_min_history:
            prev_mean = float(np.mean(hist))
            jump_ratio = abs(area - prev_mean) / max(prev_mean, 1.0)
            if jump_ratio > self.bbox_area_jump_ratio:
                now = time.monotonic()
                if now - self._last_area_jump_log_mono > 0.8:
                    self._last_area_jump_log_mono = now
                    self.get_logger().warn(
                        f'haomu bbox area spike suppressed: slot={slot} area={area:.0f} '
                        f'mean={prev_mean:.0f} jump={jump_ratio:.2f}'
                    )
                return prev_mean

        hist.append(area)
        return float(np.mean(hist))


    def _select_haomu_detection(self, detections: list):
        """
        当检测到多个 haomu 时：
        1. 按 x 坐标为 haomu 检测分配稳定槽位；
        2. 用最近 bbox_area_history_len 帧面积均值参与“面积前二”筛选，抑制单帧框大小突变；
        3. 再根据 left_or_right 选择偏左(0)或偏右(1)的那个。

        其余类别保持不变；若 haomu 数量不足 2，则保持原有结果。
        """
        # 用归一化类名匹配（大小写、'_' '-' 空格等价）
        haomu_detections = [det for det in detections
                            if _logic.is_target_class(det.class_name, self._target_norm)]

        if len(haomu_detections) < 2:
            if len(haomu_detections) == 1:
                self._stable_haomu_area(haomu_detections[0], 0)
            return detections

        if self.multi_target_selection != 'area_left_right':
            keep = haomu_detections[_logic.pick_target_index(
                [(float(d.confidence), d.x, d.y, d.width, d.height) for d in haomu_detections],
                self.multi_target_selection)]
            filtered = [det for det in detections
                        if not _logic.is_target_class(det.class_name, self._target_norm)]
            filtered.append(keep)
            return filtered

        by_x = sorted(haomu_detections, key=lambda det: float(det.x) + 0.5 * float(det.width))
        stable_area = {}
        for slot, det in enumerate(by_x):
            stable_area[id(det)] = self._stable_haomu_area(det, slot)

        top2 = sorted(
            haomu_detections,
            key=lambda det: stable_area.get(id(det), float(det.width) * float(det.height)),
            reverse=True,
        )[:2]

        choose_right = 1 if int(self.left_or_right) == 1 else 0
        selected_haomu = sorted(
            top2,
            key=lambda det: float(det.x) + 0.5 * float(det.width),
        )[-1 if choose_right else 0]

        filtered = [det for det in detections
                    if not _logic.is_target_class(det.class_name, self._target_norm)]
        filtered.append(selected_haomu)
        return filtered

    def _load_model(self, model_path: str, device: str) -> YOLO:
        """
        仅加载 OpenVINO 格式模型目录（不读取 .pt，不做导出）
        """
        model_path = Path(model_path)

        if not model_path.exists():
            self.get_logger().error(f'OpenVINO model path not found: {model_path}')
            raise FileNotFoundError(f'OpenVINO model path not found: {model_path}')

        def _prepare_openvino_dir_alias(src_dir: Path) -> Path | None:
            """为不符合 *_openvino_model 命名的目录创建兼容别名目录。"""
            if not src_dir.is_dir():
                return None

            xml_files_local = sorted(src_dir.glob('*.xml'))
            bin_files_local = sorted(src_dir.glob('*.bin'))
            if not xml_files_local or not bin_files_local:
                return None

            if src_dir.name.endswith('_openvino_model'):
                return src_dir

            xml_stem = xml_files_local[0].stem
            alias_root = Path(tempfile.gettempdir()) / 'yolo_node_openvino_alias'
            alias_root.mkdir(parents=True, exist_ok=True)
            alias_dir = alias_root / f'{xml_stem}_openvino_model'

            if alias_dir.exists():
                try:
                    if alias_dir.is_symlink() or alias_dir.is_file():
                        alias_dir.unlink()
                    elif alias_dir.is_dir():
                        shutil.rmtree(alias_dir)
                except Exception:
                    pass

            # 优先软链接，失败则复制
            try:
                alias_dir.symlink_to(src_dir, target_is_directory=True)
                self.get_logger().info(f'Created OpenVINO alias symlink: {alias_dir} -> {src_dir}')
            except Exception:
                shutil.copytree(src_dir, alias_dir)
                self.get_logger().info(f'Created OpenVINO alias copy: {alias_dir} (from {src_dir})')

            return alias_dir

        # Read the exported task so detection models are not forced through
        # the segmentation code path.
        model_task = 'segment'
        metadata_path = model_path / 'metadata.yaml' if model_path.is_dir() else None
        if metadata_path and metadata_path.exists():
            try:
                metadata = yaml.safe_load(metadata_path.read_text(encoding='utf-8')) or {}
                candidate_task = str(metadata.get('task', model_task)).strip().lower()
                if candidate_task in ('detect', 'segment'):
                    model_task = candidate_task
            except Exception as exc:
                self.get_logger().warning(
                    f'Unable to read model metadata from {metadata_path}: {exc}')

        # 兼容不同 Ultralytics 版本：有的支持目录，有的更偏向 xml
        candidates: list[Path] = [model_path]
        alias_dir = _prepare_openvino_dir_alias(model_path)
        if alias_dir is not None and alias_dir != model_path:
            candidates.insert(0, alias_dir)
        xml_files = sorted(model_path.glob('*.xml')) if model_path.is_dir() else []
        candidates.extend(xml_files)

        last_error: Exception | None = None
        for candidate in candidates:
            try:
                self.get_logger().info(f'Trying OpenVINO model: {candidate}')
                loaded = YOLO(str(candidate), task=model_task)
                # 提前触发后端初始化，尽早暴露加载问题
                dummy = np.zeros((640, 640, 3), dtype=np.uint8)
                _ = loaded.predict(source=dummy, device=device, verbose=False)
                return loaded
            except Exception as e:
                last_error = e
                self.get_logger().warning(f'Failed to load OpenVINO model from {candidate}: {e}')

        raise RuntimeError(
            f'Unable to load OpenVINO model from {model_path}. Last error: {last_error}'
        )
    
    def image_callback(self, msg: Image):
        """
        图像回调函数 - 仅缓存最新图像，实际推理在后台线程执行
        """
        now = time.monotonic()
        with self._stat_lock:
            self._images_received += 1
            self._last_image_mono = now
            if self._first_image_mono is None:
                self._first_image_mono = now
            if self._wait_since_mono is None:
                self._wait_since_mono = now
        with self._image_cv:
            self._latest_image_item = (msg, now)
            self._image_cv.notify()

    def _inference_worker(self):
        while self._worker_running:
            try:
                with self._image_cv:
                    while self._worker_running and self._latest_image_item is None:
                        self._image_cv.wait(timeout=0.1)
                    if not self._worker_running:
                        return
                    item = self._latest_image_item
                    self._latest_image_item = None
                    with self._stat_lock:
                        self._wait_since_mono = None
                        self._busy_since_mono = time.monotonic() if item is not None else None

                if item is None:
                    continue
                msg, recv_mono = item
                try:
                    self._process_image(msg, recv_mono)
                finally:
                    with self._stat_lock:
                        self._busy_since_mono = None
                self._publish_status()          # state transitions only
            except Exception as e:
                # never let an unexpected exception silently kill the worker thread
                with self._stat_lock:
                    self._worker_loop_errors += 1
                    self._last_error = f'worker loop: {type(e).__name__}: {e}'[:400]
                try:
                    self.get_logger().error(f'inference worker loop error (continuing): {e}\n{traceback.format_exc()}')
                except Exception:
                    pass
                time.sleep(0.2)

    def _process_image(self, msg: Image, recv_mono: float = 0.0):
        """
        图像回调函数 - 处理接收到的 RGB 图像
        """
        try:
            t_total0 = time.monotonic()
            t_convert0 = time.monotonic()
            queue_delay_ms = (t_total0 - recv_mono) * 1000.0 if recv_mono > 0.0 else 0.0
            # 将 ROS Image 消息转换为 OpenCV 格式
            try:
                if self._cv_bridge_ok:
                    try:
                        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
                    except Exception as e:
                        self._cv_bridge_ok = False
                        self.get_logger().error(
                            f'cv_bridge failed ({e}); falling back to raw conversion'
                        )
                        cv_image = _image_msg_to_bgr(msg)
                else:
                    cv_image = _image_msg_to_bgr(msg)
            except Exception as e:
                self._record_failure('convert', e)
                self.get_logger().error(f'Image conversion failed: {e}', throttle_duration_sec=5.0)
                return

            convert_ms = (time.monotonic() - t_convert0) * 1000.0

            # 运行 YOLO 推理
            t_infer0 = time.monotonic()
            try:
                results = self.model.predict(
                    source=cv_image,
                    conf=self.conf_threshold,
                    iou=self.iou_threshold,
                    device=self.device,
                    verbose=False
                )
            except Exception as e:
                self._record_failure('inference', e)
                self.get_logger().error(f'Inference failed: {e}', throttle_duration_sec=5.0)
                return
            infer_ms = (time.monotonic() - t_infer0) * 1000.0
            
            # 创建检测结果消息
            detection_array_msg = self.DetectionArray()
            detection_array_msg.header = msg.header
            max_confidence = 0.0
            
            t_post0 = time.monotonic()

            # 解析检测结果
            for result in results:
                boxes = result.boxes
                if boxes is not None and len(boxes) > 0:
                    for i in range(len(boxes)):
                        detection_msg = self.Detection()
                        
                        # 边界框坐标 (xyxy 格式转为 xywh)
                        xyxy = boxes.xyxy[i].cpu().numpy()
                        detection_msg.x = float(xyxy[0])
                        detection_msg.y = float(xyxy[1])
                        detection_msg.width = float(xyxy[2] - xyxy[0])
                        detection_msg.height = float(xyxy[3] - xyxy[1])
                        
                        # 置信度
                        confidence = float(boxes.conf[i].cpu().numpy())
                        detection_msg.confidence = confidence
                        if confidence > max_confidence:
                            max_confidence = confidence
                        
                        # 类别 ID 和名称
                        class_id = int(boxes.cls[i].cpu().numpy())
                        detection_msg.class_id = class_id
                        detection_msg.class_name = self.model.names.get(class_id, f'class_{class_id}')
                        
                        detection_array_msg.detections.append(detection_msg)
            
            # 对 haomu 做后处理：多个同类目标时，仅保留按规则选中的一个
            selected_detections = self._select_haomu_detection(detection_array_msg.detections)
            if len(selected_detections) != len(detection_array_msg.detections):
                detection_array_msg.detections = selected_detections

            # 门控只看目标类别的最大置信度（归一化类名匹配），不再对所有类别取 max
            raw_n, target_n, max_confidence = _logic.target_stats(
                ((d.class_name, d.confidence) for d in detection_array_msg.detections),
                self._target_norm)
            if not self._target_class_valid:
                max_confidence = 0.0      # invalid target_class: never publish

            # 发布门控：仅当 max_confidence 持续超过阈值指定时长后才允许发布
            now_sec = self.get_clock().now().nanoseconds / 1e9
            should_publish = False

            if max_confidence > self.publish_conf_threshold:
                if self.high_conf_start_time_sec is None:
                    self.high_conf_start_time_sec = now_sec
                    self.get_logger().info(
                        f'[GRASP][detection][WAIT_HOLD] max_conf={max_confidence:.3f}',
                        throttle_duration_sec=5.0
                    )

                hold_elapsed = now_sec - self.high_conf_start_time_sec
                if hold_elapsed >= self.publish_hold_seconds:
                    should_publish = True
                    if not self.publish_gate_open:
                        self.publish_gate_open = True
                        self.get_logger().info(
                            f'Publish gate opened: confidence>{self.publish_conf_threshold} '
                            f'held for {hold_elapsed:.3f}s. Publishing enabled.',
                            throttle_duration_sec=5.0
                        )
            else:
                if self.high_conf_start_time_sec is not None or self.publish_gate_open:
                    self.get_logger().info(
                        f'Publish gate reset (max_conf={max_confidence:.3f} <= '
                        f'{self.publish_conf_threshold}). Publishing paused.',
                        throttle_duration_sec=5.0
                    )
                self.high_conf_start_time_sec = None
                self.publish_gate_open = False

            post_ms = (time.monotonic() - t_post0) * 1000.0

            # 'no empty message' contract: only publish when at least one target-class box passed the gate
            should_publish = should_publish and target_n > 0 and self._target_class_valid
            self._record_success(raw_n, target_n, max_confidence, should_publish)

            if should_publish:
                # 发布检测结果
                self.detection_publisher.publish(detection_array_msg)

                # 发布带标注的图像
                if self.annotated_image_publisher.get_subscription_count() > 0:
                    annotated_frame = cv_image.copy()
                    for det in detection_array_msg.detections:
                        x1 = int(round(det.x))
                        y1 = int(round(det.y))
                        x2 = int(round(det.x + det.width))
                        y2 = int(round(det.y + det.height))
                        cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        label = f"{det.class_name} {det.confidence:.2f}"
                        cv2.putText(
                            annotated_frame,
                            label,
                            (x1, max(0, y1 - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5,
                            (0, 255, 0),
                            1,
                            cv2.LINE_AA,
                        )
                    if self._cv_bridge_ok:
                        annotated_msg = self.bridge.cv2_to_imgmsg(
                            annotated_frame, encoding='bgr8'
                        )
                        annotated_msg.header = msg.header
                    else:
                        annotated_msg = _bgr_to_image_msg(annotated_frame, msg.header)
                    self.annotated_image_publisher.publish(annotated_msg)
            
            # 终端计时日志
            total_ms = (time.monotonic() - t_total0) * 1000.0
            self._log_timing(
                queue_delay_ms=queue_delay_ms,
                convert_ms=convert_ms,
                infer_ms=infer_ms,
                post_ms=post_ms,
                total_ms=total_ms,
                num_detections=len(detection_array_msg.detections),
                max_confidence=max_confidence,
                should_publish=should_publish)

            # 日志输出检测数量
            num_detections = len(detection_array_msg.detections)
            if num_detections > 0:
                self.get_logger().debug(f'Detected {num_detections} objects')
                
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')
            self.get_logger().error(traceback.format_exc())

    def _log_timing(self, queue_delay_ms, convert_ms, infer_ms, post_ms, total_ms,
                    num_detections, max_confidence, should_publish):
        if not self.timing_log_enable:
            return
        now = time.monotonic()
        if now - self._last_timing_log_mono < self.timing_log_throttle_sec:
            return
        self._last_timing_log_mono = now
        self.get_logger().info(
            f"[GRASP][detection][STATUS] total={total_ms:.0f}ms | queue={queue_delay_ms:.0f} "
            f"convert={convert_ms:.0f} infer={infer_ms:.0f} post={post_ms:.0f}ms | "
            f"det={num_detections} max_conf={max_confidence:.2f} publish={should_publish}",
            throttle_duration_sec=5.0)

    def destroy_node(self):
        if hasattr(self, '_status_stop'):
            self._status_stop.set()
        self._worker_running = False
        with self._image_cv:
            self._image_cv.notify_all()
        if hasattr(self, '_worker_thread'):
            self._worker_thread.join(timeout=1.0)
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    node = YoloDetectorNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        # rclpy's own SIGINT handler may already have shut the context down; calling shutdown() again
        # raised RCLError and made the process exit with code 1 on every Ctrl-C / launch SIGINT.
        if rclpy.ok():
            rclpy.shutdown()
        _reap_helper_processes()


if __name__ == '__main__':
    main()
